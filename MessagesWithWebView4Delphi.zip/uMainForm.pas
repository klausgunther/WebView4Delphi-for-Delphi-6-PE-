unit uMainForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ExtCtrls, ComCtrls, StdCtrls,
  uWVBrowser, uWVWinControl, uWVWindowParent, uWVTypes, uWVConstants, uWVTypeLibrary,
  uWVLibFunctions, uWVLoader, uWVInterfaces, uWVCoreWebView2Args,
  uWVBrowserBase, uWVCoreWebView2SharedBuffer, uWebBrowserForm;

type
  TForm1 = class(TForm)
    MessagesPnl: TPanel;
    Edit1: TEdit;
    SendMsgBtn: TButton;
    Panel1: TPanel;
    Panel2: TPanel;
    Label1: TLabel;
    Label2: TLabel;
    SharedBufferEdt: TEdit;
    PostSharedBufferBtn: TButton;
    Panel3: TPanel;
    Button2: TButton;
    OpenDialog1: TOpenDialog;
    ScrollBar1: TScrollBar;
    ScrollBar2: TScrollBar;
    MessagesList: TListBox;
    Panel4: TPanel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    ScrollBar3: TScrollBar;
    ScrollBar4: TScrollBar;
    procedure SendMsgBtnClick(Sender: TObject);

    procedure WVBrowser1InitializationError(Sender: TObject; aErrorCode: HRESULT; const aErrorMessage: wvstring);
    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure Button2Click(Sender: TObject);
    procedure ScrollBar1Change(Sender: TObject);
    procedure ScrollBar2Change(Sender: TObject);
    procedure ScrollBar3Change(Sender: TObject);
    procedure ScrollBar4Change(Sender: TObject);

  protected
    FSharedBuffer : TCoreWebView2SharedBuffer;
    procedure WMMove(var aMessage : TWMMove); message WM_MOVE;
    procedure WMMoving(var aMessage : TMessage); message WM_MOVING;

  private
    { D�clarations priv�es }
  public
    { D�clarations publiques }
  end;

var
  Form1: TForm1;
  WB: TWebBrowserForm;
  WVBrowser1: TWVBrowser;
  SndMessage: string;

function InitializeWebView4Delphi: integer; stdcall; external 'DllBrowser.dll';
function FinalizeWebView4Delphi: integer; stdcall; external 'DllBrowser.dll';
function ShowBrowser(aDest: HWND; aBorderLess: integer; aX,aY,aW,aH: integer): integer; stdcall; external 'DllBrowser.dll';
function SetBrowserMessageCommunication(aWB: TWebBrowserForm; aAllow: integer; aSndBuffer, aRcvBuffer: HWND): integer; stdcall; external 'DllBrowser.dll';

implementation

{$R *.dfm}

const
  CUSTOM_SHARED_BUFFER_SIZE = 1024;

procedure TForm1.SendMsgBtnClick(Sender: TObject);
begin
  WVBrowser1.PostWebMessageAsString(Edit1.Text);
end;

procedure TForm1.WVBrowser1InitializationError(Sender: TObject;
  aErrorCode: HRESULT; const aErrorMessage: wvstring);
begin
  showmessage(aErrorMessage);
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  InitializeWebView4Delphi;
  WB := TWebBrowserForm(ShowBrowser(Form1.Handle,1,  0,0,620,650));
  FSharedBuffer := nil;
  WVBrowser1 := WB.WVBrowser1;
end;

procedure TForm1.WMMove(var aMessage : TWMMove);
begin
exit;
  inherited;

  if (WVBrowser1 <> nil) then
    WVBrowser1.NotifyParentWindowPositionChanged;
end;

procedure TForm1.WMMoving(var aMessage : TMessage);
begin
exit;
  inherited;

  if (WVBrowser1 <> nil) then
    WVBrowser1.NotifyParentWindowPositionChanged;
end;

procedure TForm1.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  FinalizeWebView4Delphi;
end;


procedure TForm1.Button2Click(Sender: TObject);
var
  URL: string;
begin
  if not OpenDialog1.Execute then exit;
  URL := 'File:///' + OpenDialog1.FileName;
  WVBrowser1.Navigate(URL);
  ScrollBar3.OnChange := nil;
  ScrollBar4.OnChange := nil;

  ScrollBar1.Min := 0;
  ScrollBar2.Min := 0;
  ScrollBar3.Min := 0;
  ScrollBar4.Min := 0;

  ScrollBar1.Max := 40000;
  ScrollBar2.Max := 275;
  ScrollBar3.Max := 4000;
  ScrollBar4.Max := 600;
  ScrollBar3.Position := 1000;
  ScrollBar4.Position := 275;

  ScrollBar3.OnChange := ScrollBar3Change;
  ScrollBar4.OnChange := ScrollBar4Change;
  SetBrowserMessageCommunication(WB,1, 0,MessagesList.Handle);

  // here, the WVBrowser's scrollbars should be hidden !
  // ...
end;

procedure TForm1.ScrollBar1Change(Sender: TObject);
begin
  WVBrowser1.ExecuteScriptWithResult('ShiftHorz('+inttostr(Scrollbar1.Position)+')');
end;

procedure TForm1.ScrollBar2Change(Sender: TObject);
begin
  WVBrowser1.ExecuteScriptWithResult('ShiftVert('+inttostr(Scrollbar2.Position)+')');
end;

procedure TForm1.ScrollBar3Change(Sender: TObject);
begin
  WVBrowser1.ExecuteScriptWithResult('ZoomHorz('+inttostr(Scrollbar3.Position)+')');
  Label3.Caption := 'Horizontal Zoom '+inttostr(Scrollbar3.Position);
end;

procedure TForm1.ScrollBar4Change(Sender: TObject);
begin
  WVBrowser1.ExecuteScriptWithResult('ZoomVert('+inttostr(Scrollbar4.Position)+')');
  Label3.Caption := 'Vertical Zoom '+inttostr(Scrollbar4.Position);
end;

end.
