unit uWebBrowserForm;
                                                     
interface

// added by Klaus Fischer le 05/03/2026
//   support to manage WebMessages  Browser--> Delphi  and  Delphi-->Browser

{$I webview2.inc}

uses
  {$IFDEF DELPHI16_UP}
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.ExtCtrls, Vcl.ComCtrls, Vcl.StdCtrls,
  {$ELSE}
  Windows, Messages, SysUtils, Variants, Classes, Graphics,
  Controls, Forms, Dialogs, ExtCtrls, ComCtrls, StdCtrls,
  {$ENDIF}
  uWVBrowser, uWVWinControl, uWVWindowParent, uWVTypes, uWVConstants, uWVTypeLibrary,
  uWVLibFunctions, uWVLoader, uWVInterfaces, uWVCoreWebView2Args,
  uWVBrowserBase, uWVCoreWebView2SharedBuffer;

type
  TWebBrowserFormHelper = class
    private
    published
      class procedure NavigationCompleted(Sender: TObject; const aWebView: ICoreWebView2; const aArgs: ICoreWebView2NavigationCompletedEventArgs);
  end;

type
  TWebBrowserForm = class(TForm)
    WVWindowParent1: TWVWindowParent;
    Timer1: TTimer;
    WVBrowser1: TWVBrowser;
    AddressPnl: TPanel;
    AddressCb: TComboBox;
    GoBtn: TButton;

    procedure Timer1Timer(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure GoBtnClick(Sender: TObject);

    procedure WVBrowser1AfterCreated(Sender: TObject);
    procedure WVBrowser1DocumentTitleChanged(Sender: TObject);
    procedure WVBrowser1InitializationError(Sender: TObject; aErrorCode: HRESULT; const aErrorMessage: wvstring);

  private
    fBrowserReady: boolean;
    // The messages should be single line text messages.
    // If a message contains a multi-line text, the calling application must be able to handle this.
    fSndMessageBuffer: HWND;        // Handle of a Delphi object containing the message to send
    fRcvMessageBuffer: HWND;        // Handle of a Delphi TList object receiving a new message on arrival
      // these Delphi objects should be used with an OnChange event.
      // the SndMessageBuffer will be erased on send completion. So the calling program will be noticed.
      // a new message will be added to the RcvMessageBuffer. So the calling program will be noticed.
      // the calling program must allways handle the element [0] first, then delete it, until list is empty.
  published
    property BrowserReady: boolean read fBrowserReady write fBrowserReady;
    property SndMessageBuffer: HWND read fSndMessageBuffer write fSndMessageBuffer;
    property RcvMessageBuffer: HWND read fRcvMessageBuffer write fRcvMessageBuffer;

  protected
    // It's necessary to handle these messages to call NotifyParentWindowPositionChanged or some page elements will be misaligned.
    procedure WMMove(var aMessage : TWMMove); message WM_MOVE;
    procedure WMMoving(var aMessage : TMessage); message WM_MOVING;

  public
    { Public declarations }
  end;

var
  WebBrowserForm: TWebBrowserForm;

implementation

{$R *.dfm}

// This is a demo with the simplest web browser you can build using WebView4Delphi and
// it doesn't show any sign of progress like other web browsers do.

// Remember that it may take a few seconds to load if Windows update, your antivirus or
// any other windows service is using your hard drive.

// Depending on your internet connection it may take longer than expected.

// Please check that your firewall or antivirus are not blocking this application
// or the domain "bing.com".

// The "initialization" section in this unit loads GlobalWebView2Loader which will create
// the global environment asynchronously.

// The browser needs the global environment but the form might be created before that so we
// use a simple timer to create the browser in case the environment is not ready when
// TForm.OnShow is triggered.

// GlobalWebView2Loader will be destroyed automatically in the "finalization" section of
// uWVLoader.pas. All browsers should be already destroyed before GlobalWebView2Loader
// is destroyed.

const
  CUSTOM_SHARED_BUFFER_SIZE = 1024;


procedure TWebBrowserForm.FormShow(Sender: TObject);
begin
  if GlobalWebView2Loader.InitializationError then
    showmessage(GlobalWebView2Loader.ErrorMessage)
   else
    if GlobalWebView2Loader.Initialized then
      WVBrowser1.CreateBrowser(WVWindowParent1.Handle)
     else
      Timer1.Enabled := True;
end;

procedure TWebBrowserForm.GoBtnClick(Sender: TObject);
begin
  WVBrowser1.Navigate(AddressCb.Text);
end;

procedure TWebBrowserForm.WVBrowser1AfterCreated(Sender: TObject);
begin
  WVWindowParent1.UpdateSize;
  WVWindowParent1.SetFocus;
  Caption := 'SimpleBrowser';
  AddressPnl.Enabled := True;
  BrowserReady := true;
end;

procedure TWebBrowserForm.WVBrowser1DocumentTitleChanged(Sender: TObject);
begin
  Caption := 'SimpleBrowser - ' + WVBrowser1.DocumentTitle;
end;

procedure TWebBrowserForm.WVBrowser1InitializationError(Sender: TObject;
  aErrorCode: HRESULT; const aErrorMessage: wvstring);
begin
  showmessage(aErrorMessage);
end;

procedure TWebBrowserForm.Timer1Timer(Sender: TObject);
begin
  Timer1.Enabled := False;

  if GlobalWebView2Loader.Initialized then begin
    WVBrowser1.CreateBrowser(WVWindowParent1.Handle);
    WVBrowser1.OnNavigationCompleted := TWebBrowserFormHelper.NavigationCompleted;
   end else
    Timer1.Enabled := True;
end;

class procedure TWebBrowserFormHelper.NavigationCompleted(Sender: TObject; const aWebView: ICoreWebView2; const aArgs: ICoreWebView2NavigationCompletedEventArgs);
begin
  TWVBrowser(Sender).Isready := true;
end;

procedure TWebBrowserForm.WMMove(var aMessage : TWMMove);
begin
  inherited;

  if (WVBrowser1 <> nil) then
    WVBrowser1.NotifyParentWindowPositionChanged;
end;

procedure TWebBrowserForm.WMMoving(var aMessage : TMessage);
begin
  inherited;

  if (WVBrowser1 <> nil) then
    WVBrowser1.NotifyParentWindowPositionChanged;
end;

end.
