library DLLBrowser;

uses
  Windows, Forms, Messages, Controls, SysUtils, Classes, StrUtils, dialogs,
  KGF_unit_StringInterface,
  uWVBrowser, uWVWinControl, uWVWindowParent, uWVTypes, uWVConstants, uWVTypeLibrary,
  uWVLibFunctions, uWVLoader, uWVInterfaces, uWVCoreWebView2Args,
  uWVBrowserBase, uWVCoreWebView2SharedBuffer, uWebBrowserForm;

{$R *.res}

function InitializeWebView4Delphi: integer; stdcall; export;
begin
  result := -1;
  try
    GlobalWebView2Loader                := TWVLoader.Create(nil);
    GlobalWebView2Loader.UserDataFolder := IncludeTrailingPathDelimiter(ExtractFileDir(GetModuleName(HINSTANCE))) + '\CustomCache';
    GlobalWebView2Loader.StartWebView2;
    result := 0;
  except
  end;
end;

function FinalizeWebView4Delphi: integer; stdcall; export;
begin
  result := -1;
  try
    DestroyGlobalWebView2Loader;
    result := 0;
  except
  end;
end;

function ShowBrowser(aDest: HWND; aBorderLess: integer; aX,aY,aW,aH: integer): integer; stdcall; export;
begin
  result := 0;
  try
    WebBrowserForm := TWebBrowserForm.Create(nil);
    if aBorderLess<>0 then WebBrowserForm.BorderStyle := bsNone;
    if aDest<>0 then WebBrowserForm.ParentWindow := aDest;
    WebBrowserForm.Show;
    if (aX+aY+aW+aH)<>0 then WebBrowserForm.SetBounds(aX,aY,aW,aH);
    result := integer(WebBrowserForm);
  except
  end;
end;

function SetBrowserMessageCommunication(aWB: TWebBrowserForm; aAllow: integer; aSndBuffer, aRcvBuffer: HWND): integer; stdcall; export;
// aAllow=0: bloquer  aAllow<>0: permettre
// aSndBuffer: adresse (pointer) vers le buffer de message � envoyer
// aRecBuffer: adresse (pointer) vers le buffer de r�ception de messages
var
  temp: boolean;
begin
  result := -1;
  try
    if not assigned(aWB) then exit;
    if aWB.ClassName<>'TWebBrowserForm' then exit;

    temp := aWB.WVBrowser1.WebMessageEnabled;
    aWB.WVBrowser1.SndMessageBuffer := aSndBuffer;
    aWB.WVBrowser1.RcvMessageBuffer := aRcvBuffer;
    aWB.WVBrowser1.WebMessageEnabled := (aAllow<>0);
    aWB.WVBrowser1.SetMessageReceiver;
    if temp then result := 1
            else result := 0;
  except
  end;
end;

function SendMessageToBrowser(aWB: TWebBrowserForm; aMessage: integer): integer; stdcall; export;
var
  msg: string;
begin
  result := -1;
  try
    if not assigned(aWB) then exit;
    if aWB.ClassName<>'TWebBrowserForm' then exit;
    msg := Trim(GetStringFromPanoramic(aMessage));
    if msg='' then exit;

  except
  end;
end;
exports SetBrowserMessageCommunication;

exports
  InitializeWebView4Delphi,
  FinalizeWebView4Delphi,
  ShowBrowser,
  SetBrowserMessageCommunication;

begin
end.

