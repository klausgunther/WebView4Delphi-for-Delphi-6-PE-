let xClick = 0;
let yClick = 0;
let col = 0;
let row = 0;
let BaseX = 0;
let BaseY = 0;

document.addEventListener('click', function(event) {
    const x = event.clientX
    const y = event.clientY
  	xClick = BaseX + x - 8;
	yClick = BaseY + y - 8;
    col = Math.trunc((xClick+99)/100)-1;
    row = Math.trunc((yClick+24)/25)-1;	
	const Point = Object({
	    cpx: col, 
		cpy: row
	});
	document.getElementById("msgtext").Value  = xClick+","+yClick+"/"+Point.cpx + "," + Point.cpy;
	sendMessageToHostApp();
})

function sendMessageToHostApp() {
	let data = document.getElementById("msgtext").Value;
    window.chrome.webview.postMessage(data);
}

function ShiftRight(){
	const svg = document.querySelector("svg");
    const vBox = svg.viewBox;
	vBox.baseVal.x = vBox.baseVal.x + 800;
	BaseX = vBox.baseVal.x;
}
 
 function ShiftLeft(){
	const svg = document.querySelector("svg");
    const vBox = svg.viewBox;
	vBox.baseVal.x = vBox.baseVal.x - 800;
	BaseX = vBox.baseVal.x;
}

function ShiftDown(){
	const svg = document.querySelector("svg");
    const vBox = svg.viewBox;
	vBox.baseVal.y = vBox.baseVal.y + 25*5;
	BaseY = vBox.baseVal.y;
}

function ShiftHorz(p){
	const svg = document.querySelector("svg");
    const vBox = svg.viewBox;
	vBox.baseVal.x = p;
	BaseX = p;
}

function ShiftVert(p){
	const svg = document.querySelector("svg");
    const vBox = svg.viewBox;
	vBox.baseVal.y = p;
	BaseY = p;
}

function ShiftHome(){
	const svg = document.querySelector("svg");
    const vBox = svg.viewBox;
	vBox.baseVal.x = 0;
	vBox.baseVal.y = 0;
	BaseX = 0;
	BaseY = 0;
}

function ZoomHorz(p){
	const svg = document.querySelector("svg");
    const vBox = svg.viewBox;
	vBox.baseVal.width = p;
}

function ZoomVert(p){
	const svg = document.querySelector("svg");
    const vBox = svg.viewBox;
	vBox.baseVal.height = p;
}




